<?php
// 测试压缩功能
require 'admin/compress.php';

$content = file_get_contents('test_compress_sample.php');

echo "=== 原始代码 ===\n";
echo $content;
echo "\n\n";

echo "=== 压缩后代码 ===\n";
$compressed = compressPhpSafe($content);
echo $compressed;
echo "\n\n";

echo "=== 统计信息 ===\n";
echo "原始大小: " . strlen($content) . " 字节\n";
echo "压缩后大小: " . strlen($compressed) . " 字节\n";
echo "节省: " . (strlen($content) - strlen($compressed)) . " 字节\n";
echo "压缩率: " . round((1 - strlen($compressed) / strlen($content)) * 100, 2) . "%\n";
