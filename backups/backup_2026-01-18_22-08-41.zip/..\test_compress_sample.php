<?php
// 这是一个测试文件
// 用于测试代码压缩功能

/**
 * 这是一个多行注释
 * 用于测试压缩
 */

function testFunction() {
    // 获取数据
    $data = getData();
    
    // 处理数据
    $result = processData($data);
    
    // 返回结果
    return $result;
}

// 另一个函数
function anotherFunction() {
    $x = 1;
    $y = 2;
    
    // 计算
    $sum = $x + $y;
    
    return $sum;
}

/**
 * @license MIT License
 * @copyright 2026 Test
 * @author Test Author
 */
class TestClass {
    // 类属性
    private $name;
    
    // 构造函数
    public function __construct($name) {
        $this->name = $name;
    }
    
    // 获取名称
    public function getName() {
        return $this->name;
    }
}
